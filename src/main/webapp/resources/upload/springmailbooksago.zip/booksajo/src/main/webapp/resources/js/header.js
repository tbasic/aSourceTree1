	function drop(num){
        
		if (num==1) {
			
		//국내도서 마우스 호버이벤트
			$(document).ready(function(){
				$("nav").mouseover(function(){
					
				});
			});
			
		}else if (num==2) {
			
			//외국도서 마우스 호버이벤트
		}
	
}