package com.tech.booksajo.login.vo;

public class SignInVO {
	
	private String user_id;
	private String user_nickname;
	private String user_gender;
	private int user_age;
	private String user_name;
	private String user_phone;
	private String user_addr;
	private String user_email;
	private String user_shapw;
	private String user_bcpw;
	private int user_mailcheck;
	private int user_verification;
	
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_nickname() {
		return user_nickname;
	}
	public void setUser_nickname(String user_nickname) {
		this.user_nickname = user_nickname;
	}
	public String getUser_gender() {
		return user_gender;
	}
	public void setUser_gender(String user_gender) {
		this.user_gender = user_gender;
	}
	public int getUser_age() {
		return user_age;
	}
	public void setUser_age(int user_age) {
		this.user_age = user_age;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_phone() {
		return user_phone;
	}
	public void setUser_phone(String user_phone) {
		this.user_phone = user_phone;
	}
	public String getUser_addr() {
		return user_addr;
	}
	public void setUser_addr(String user_addr) {
		this.user_addr = user_addr;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_shapw() {
		return user_shapw;
	}
	public void setUser_shapw(String user_shapw) {
		this.user_shapw = user_shapw;
	}
	public String getUser_bcpw() {
		return user_bcpw;
	}
	public void setUser_bcpw(String user_bcpw) {
		this.user_bcpw = user_bcpw;
	}
	public int getUser_mailcheck() {
		return user_mailcheck;
	}
	public void setUser_mailcheck(int user_mailcheck) {
		this.user_mailcheck = user_mailcheck;
	}
	public int getUser_verification() {
		return user_verification;
	}
	public void setUser_verification(int user_verification) {
		this.user_verification = user_verification;
	}
	
	
	
	
	
	

	
	
	
}
