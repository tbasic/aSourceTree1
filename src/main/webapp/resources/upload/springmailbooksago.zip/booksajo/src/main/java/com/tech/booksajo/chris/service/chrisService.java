package com.tech.booksajo.chris.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;


public interface chrisService {
	
	List<Map<String,Object>> getList();

}
