package com.tech.booksajo.bdboard.service;

import java.util.List;
import java.util.Map;


public interface BdboardService  {
	
	List<Map<String,Object>> getList();

}

