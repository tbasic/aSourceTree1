package com.tech.booksajo.search.vo;

public class SearchPage {
/*서치 페이지 넘긴느거 관련해서 필요한 변수들*/
}
